package org.example;

import org.example.Interface.GUI;

public class Main {
    public static void main(String[] args) {
        //Polynomial pol1=new Polynomial();
        //Polynomial pol2=new Polynomial();
        //Polynomial res=new Polynomial();
        //pol1.addMonomToPolynom(new Monom(2,2) );//2x^2
        //pol1.addMonomToPolynom(new Monom(1,1));//x
        //pol2.addMonomToPolynom(new Monom(2,3));//3x^2
        //pol2.addMonomToPolynom(new Monom(0,4));
        //res=Operations.add(pol1,pol2);
        //System.out.println(res.toString());

        GUI view=new GUI();
        view.setVisible(true);

    }
}